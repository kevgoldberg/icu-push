# icu-push

A deliberately small MCP server that writes planned workouts to Intervals.icu,
which then syncs them to Garmin Connect and onto the watch.

Built for Kevin's Ironman system. Two tools, no delete path, bearer-token gated.

## Why it is this small

The deployed URL is reachable from the public internet, because Claude's
connector infrastructure has to call it, and it holds an Intervals.icu API key
that can read and rewrite an entire training history. General-purpose
Intervals.icu MCP servers expose 50-60 tools including deletes; behind a public
URL that is 60 tools for whoever finds it. This exposes two.

Limits enforced in code, not by instruction:

| Limit | Effect |
|---|---|
| WORKOUT category only | cannot create races, notes, goals, plans |
| Future dates only | cannot overwrite a day that already happened |
| Allowed disciplines only | Run/Ride/Swim/VirtualRide/Walk/Other. Strength, core and mobility are refused — they stay on Google Calendar |
| 40 events per call | a runaway caller cannot flood the calendar |
| No delete tool | removing an event is done in the Intervals.icu UI |
| All-or-nothing batches | one invalid event aborts the whole write |

`test_server.py` covers all of the above and runs in the Docker build, so the
image does not build if a safety property regresses.

## Idempotency

Every event gets a deterministic `external_id`
(`ironman-<date>-<discipline>-<slug>`), and writes go to
`/events/bulk?upsert=true`. Re-running the same week updates those events
instead of duplicating them — the same guarantee the rest of the Ironman system
relies on, and one the Google Calendar connector could not provide because it
does not expose `extendedProperties`.

## Heart-rate targets

Workout descriptions use **absolute bpm ranges** (`- 50m 125-142bpm`), never
`Z2 HR`. The bands come from `zones.py` and its own anchor; expressing them as
zones would let Intervals.icu reinterpret them against its separate zone
configuration, and the two would silently drift.

## Deploy (Render free tier)

1. Put these files in a GitHub repo (public is fine — no secrets are committed).
2. Render → New → Web Service → connect the repo. It reads `render.yaml`.
3. Set three environment variables in the Render dashboard:

   | Variable | Where it comes from |
   |---|---|
   | `INTERVALS_ICU_API_KEY` | intervals.icu → Settings → Developer Settings |
   | `INTERVALS_ICU_ATHLETE_ID` | the `i123456` in your intervals.icu profile URL |
   | `MCP_BEARER_TOKEN` | generate: `python3 -c "import secrets;print(secrets.token_urlsafe(32))"` |

4. Deploy. Check `https://<your-service>.onrender.com/healthz` returns `ok`.
5. In claude.ai → Settings → Connectors → Add custom connector:
   - URL: `https://<your-service>.onrender.com/mcp`
   - Add request header: `Authorization` = `Bearer <your MCP_BEARER_TOKEN>`
6. Once it connects, set `ENFORCE_ANTHROPIC_EGRESS=true` in Render for a second
   layer (rejects any caller outside Anthropic's published `160.79.104.0/21`).

Free tier sleeps after inactivity and cold-starts in roughly 50 seconds. That is
fine for a once-a-week call; the first request just takes a moment.

## Local test

```bash
INTERVALS_ICU_API_KEY=x INTERVALS_ICU_ATHLETE_ID=i1 MCP_BEARER_TOKEN=t python3 test_server.py
```
