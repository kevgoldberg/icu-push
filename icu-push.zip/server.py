"""
icu-push — a deliberately tiny MCP server that writes planned workouts to Intervals.icu.

Why this exists instead of a general-purpose Intervals.icu MCP server:
this endpoint is reachable from the public internet (Claude's connector
infrastructure has to call it), and it holds an Intervals.icu API key that can
read and rewrite an athlete's whole training history. A 61-tool server behind
that URL means anyone who finds the URL gets all 61 tools. So the surface here
is two tools, both scoped, with no delete path of any kind.

Hard limits, enforced server-side rather than by instruction:
  * WORKOUT events only — cannot create races, notes, goals or plans.
  * Future dates only — cannot overwrite a day that has already happened.
  * MAX_EVENTS per call — a runaway caller cannot flood the calendar.
  * No delete tool exists. Removing an event is a thing you do in the UI.

Auth: a fixed bearer token, compared in constant time. Claude supports this via
its `static_headers` connector auth. Optionally also restricts to Anthropic's
published egress range.
"""

from __future__ import annotations

import hmac
import os
import re
from datetime import date, datetime
from ipaddress import ip_address, ip_network
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

BASE_URL = "https://intervals.icu/api/v1"
MAX_EVENTS = 40

# Disciplines this server is willing to write. Strength/core/mobility are
# deliberately absent: they live on the Google Calendar and do not belong on a
# watch as structured workouts.
ALLOWED_TYPES = {"Run", "Ride", "Swim", "VirtualRide", "Walk", "Other"}

ANTHROPIC_EGRESS = ip_network("160.79.104.0/21")

API_KEY = os.environ.get("INTERVALS_ICU_API_KEY", "")
ATHLETE_ID = os.environ.get("INTERVALS_ICU_ATHLETE_ID", "")
BEARER_TOKEN = os.environ.get("MCP_BEARER_TOKEN", "")
ENFORCE_EGRESS = os.environ.get("ENFORCE_ANTHROPIC_EGRESS", "").lower() in ("1", "true", "yes")

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2})?$")
_SLUG_RE = re.compile(r"[^a-z0-9]+")

mcp = FastMCP("icu-push")


def _client() -> httpx.AsyncClient:
    return httpx.AsyncClient(
        base_url=BASE_URL,
        timeout=30.0,
        auth=httpx.BasicAuth(username="API_KEY", password=API_KEY),
    )


def _slug(text: str) -> str:
    return _SLUG_RE.sub("-", text.lower()).strip("-")[:40]


def validate_event(raw: dict[str, Any], index: int, today: date | None = None) -> dict[str, Any]:
    """Normalise one event, or raise ValueError naming the problem and the index.

    Kept a plain function with no I/O so it can be tested without a network.
    """
    today = today or date.today()

    for field in ("start_date_local", "name", "type"):
        if not raw.get(field):
            raise ValueError(f"event {index}: missing required field '{field}'")

    start = str(raw["start_date_local"])
    if not _DATE_RE.match(start):
        raise ValueError(
            f"event {index}: start_date_local must be YYYY-MM-DD or "
            f"YYYY-MM-DDTHH:MM:SS, got {start!r}"
        )
    day = datetime.fromisoformat(start if "T" in start else start + "T00:00:00").date()
    if day < today:
        raise ValueError(
            f"event {index}: start_date_local {day} is in the past. This server only "
            f"writes future workouts so it can never overwrite recorded history."
        )

    etype = str(raw["type"])
    if etype not in ALLOWED_TYPES:
        raise ValueError(
            f"event {index}: type {etype!r} not allowed. Permitted: {sorted(ALLOWED_TYPES)}"
        )

    category = str(raw.get("category", "WORKOUT")).upper()
    if category != "WORKOUT":
        raise ValueError(
            f"event {index}: category must be WORKOUT (got {category!r}). This server "
            f"cannot create races, notes, goals or plans."
        )

    out: dict[str, Any] = {
        "start_date_local": start if "T" in start else start + "T00:00:00",
        "name": str(raw["name"]),
        "category": "WORKOUT",
        "type": etype,
        # Stable id => re-running the same week updates rather than duplicates.
        "external_id": str(raw.get("external_id") or f"ironman-{day}-{_slug(etype)}-{_slug(str(raw['name']))}"),
    }
    if raw.get("description"):
        out["description"] = str(raw["description"])
    if raw.get("moving_time"):
        out["moving_time"] = int(raw["moving_time"])
    return out


@mcp.tool()
async def push_training_week(events: list[dict[str, Any]]) -> str:
    """Create or update planned workouts on the Intervals.icu calendar.

    Idempotent: each event carries a stable external_id, so calling twice with
    the same week updates those events rather than creating duplicates.

    Each event: start_date_local (YYYY-MM-DDTHH:MM:SS), name, type
    (Run/Ride/Swim/VirtualRide/Walk/Other), optional moving_time (seconds) and
    description. The description should use Intervals.icu workout syntax with
    ABSOLUTE bpm ranges, e.g.:

        Warmup
        - 10m 110-125bpm

        Main
        - 50m 125-142bpm

        Cooldown
        - 10m 110-125bpm

    Absolute bpm rather than 'Z2 HR' on purpose: the bands come from the
    athlete's own anchor, and must not be reinterpreted against Intervals.icu's
    separate zone configuration.
    """
    if not events:
        return "No events supplied; nothing written."
    if len(events) > MAX_EVENTS:
        return f"Refused: {len(events)} events exceeds the {MAX_EVENTS}-event cap for one call."

    try:
        payload = [validate_event(e, i) for i, e in enumerate(events)]
    except ValueError as exc:
        return f"Refused, nothing written: {exc}"

    async with _client() as client:
        resp = await client.post(
            f"/athlete/{ATHLETE_ID}/events/bulk",
            params={"upsert": "true"},
            json=payload,
        )
        if resp.status_code >= 400:
            return f"Intervals.icu returned {resp.status_code}: {resp.text[:500]}"

    lines = [f"Wrote {len(payload)} planned workouts to Intervals.icu:"]
    for e in payload:
        lines.append(f"  {e['start_date_local'][:10]}  {e['type']:<6} {e['name']}")
    lines.append("Garmin pulls these on its own sync; allow a few minutes.")
    return "\n".join(lines)


@mcp.tool()
async def list_planned_workouts(oldest: str, newest: str) -> str:
    """List planned workouts already on the calendar between two dates (YYYY-MM-DD).

    Read-only. Use before writing to see what is already there.
    """
    for label, value in (("oldest", oldest), ("newest", newest)):
        if not _DATE_RE.match(str(value)):
            return f"Refused: {label} must be YYYY-MM-DD, got {value!r}"

    async with _client() as client:
        resp = await client.get(
            f"/athlete/{ATHLETE_ID}/events",
            params={"oldest": oldest, "newest": newest, "category": "WORKOUT"},
        )
        if resp.status_code >= 400:
            return f"Intervals.icu returned {resp.status_code}: {resp.text[:500]}"
        data = resp.json()

    if not data:
        return f"No planned workouts between {oldest} and {newest}."
    lines = [f"{len(data)} planned workouts between {oldest} and {newest}:"]
    for e in data:
        lines.append(
            f"  {str(e.get('start_date_local', ''))[:10]}  "
            f"{str(e.get('type', '?')):<6} {e.get('name', '(unnamed)')}"
            f"  [external_id={e.get('external_id') or '-'}]"
        )
    return "\n".join(lines)


class BearerAuthMiddleware:
    """ASGI gate. Rejects anything without the shared bearer token.

    MCP has no transport auth of its own, so without this the deployed URL is
    equivalent to publishing the Intervals.icu API key.
    """

    def __init__(self, app: Any, token: str, enforce_egress: bool = False) -> None:
        self.app = app
        self.token = token
        self.enforce_egress = enforce_egress

    async def __call__(self, scope: dict, receive: Any, send: Any) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        if scope.get("path") == "/healthz":
            await self._text(send, 200, "ok")
            return

        if self.enforce_egress and not self._from_anthropic(scope):
            await self._text(send, 403, "forbidden")
            return

        headers = {k.decode().lower(): v.decode() for k, v in scope.get("headers", [])}
        supplied = headers.get("authorization", "")
        expected = f"Bearer {self.token}"
        if not self.token or not hmac.compare_digest(supplied, expected):
            await self._text(send, 401, "unauthorized")
            return

        await self.app(scope, receive, send)

    @staticmethod
    def _from_anthropic(scope: dict) -> bool:
        client = scope.get("client")
        if not client:
            return False
        try:
            return ip_address(client[0]) in ANTHROPIC_EGRESS
        except ValueError:
            return False

    @staticmethod
    async def _text(send: Any, status: int, body: str) -> None:
        await send({
            "type": "http.response.start",
            "status": status,
            "headers": [(b"content-type", b"text/plain")],
        })
        await send({"type": "http.response.body", "body": body.encode()})


def build_app() -> Any:
    missing = [
        name for name, value in (
            ("INTERVALS_ICU_API_KEY", API_KEY),
            ("INTERVALS_ICU_ATHLETE_ID", ATHLETE_ID),
            ("MCP_BEARER_TOKEN", BEARER_TOKEN),
        ) if not value
    ]
    if missing:
        raise RuntimeError(f"Missing required environment variables: {', '.join(missing)}")
    return BearerAuthMiddleware(
        mcp.streamable_http_app(), token=BEARER_TOKEN, enforce_egress=ENFORCE_EGRESS
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(build_app(), host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))
