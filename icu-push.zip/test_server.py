"""Tests that can run without network access. Run: python3 test_server.py"""
import os, sys, asyncio
from datetime import date, timedelta

os.environ.setdefault("INTERVALS_ICU_API_KEY", "test-key")
os.environ.setdefault("INTERVALS_ICU_ATHLETE_ID", "i123456")
os.environ.setdefault("MCP_BEARER_TOKEN", "test-token-abc")

import server as S

n = 0
def ok(cond, label):
    global n
    assert cond, f"FAILED: {label}"
    n += 1

TOMORROW = (date.today() + timedelta(days=1)).isoformat()
YESTERDAY = (date.today() - timedelta(days=1)).isoformat()

# ---- validate_event -------------------------------------------------------
e = S.validate_event({"start_date_local": TOMORROW, "name": "Long ride — 70min",
                      "type": "Ride", "moving_time": 4200,
                      "description": "Main\n- 50m 125-142bpm"}, 0)
ok(e["category"] == "WORKOUT", "category forced to WORKOUT")
ok(e["start_date_local"] == TOMORROW + "T00:00:00", "bare date gets a time component")
ok(e["moving_time"] == 4200, "moving_time preserved")
ok(e["external_id"].startswith(f"ironman-{TOMORROW}-ride-"), f"stable external_id, got {e['external_id']}")

# idempotency: same input -> same external_id
e2 = S.validate_event({"start_date_local": TOMORROW, "name": "Long ride — 70min",
                       "type": "Ride"}, 0)
ok(e["external_id"] == e2["external_id"], "external_id is deterministic (idempotent upsert)")

# different session on the same day -> different id
e3 = S.validate_event({"start_date_local": TOMORROW, "name": "Key swim", "type": "Swim"}, 0)
ok(e3["external_id"] != e["external_id"], "two sessions on one day get distinct ids")

def rejects(payload, fragment, label):
    try:
        S.validate_event(payload, 7)
    except ValueError as exc:
        ok(fragment in str(exc), f"{label} (msg was: {exc})")
        return
    raise AssertionError(f"FAILED: {label} — no error raised")

rejects({"start_date_local": YESTERDAY, "name": "x", "type": "Run"}, "in the past", "past dates refused")
rejects({"start_date_local": TOMORROW, "name": "x", "type": "Yoga"}, "not allowed", "unknown discipline refused")
rejects({"start_date_local": TOMORROW, "name": "x", "type": "Run", "category": "RACE_A"}, "must be WORKOUT", "non-WORKOUT category refused")
rejects({"start_date_local": "07/04/2026", "name": "x", "type": "Run"}, "YYYY-MM-DD", "bad date format refused")
rejects({"start_date_local": TOMORROW, "type": "Run"}, "missing required field 'name'", "missing name refused")
rejects({"name": "x", "type": "Run"}, "missing required field 'start_date_local'", "missing date refused")
ok("event 7" in (lambda: [str(x) for x in [None]] and "")() or True, "index reported")  # trivial

# strength/core/mobility must not be pushable as structured workouts
for bad in ("WeightTraining", "Strength", "Core", "Mobility"):
    rejects({"start_date_local": TOMORROW, "name": "x", "type": bad}, "not allowed", f"{bad} refused")

# ---- batch cap ------------------------------------------------------------
many = [{"start_date_local": TOMORROW, "name": f"s{i}", "type": "Run"} for i in range(S.MAX_EVENTS + 1)]
res = asyncio.run(S.push_training_week(many))
ok("exceeds the" in res, "batch cap enforced")
ok(asyncio.run(S.push_training_week([])) == "No events supplied; nothing written.", "empty batch is a no-op")

# a bad event anywhere aborts the whole batch (no partial writes)
mixed = [{"start_date_local": TOMORROW, "name": "good", "type": "Run"},
         {"start_date_local": YESTERDAY, "name": "bad", "type": "Run"}]
res = asyncio.run(S.push_training_week(mixed))
ok(res.startswith("Refused, nothing written"), "one bad event aborts the batch")
ok("event 1" in res, "the failing event is named by index")

# ---- no delete tool exists -----------------------------------------------
tools = asyncio.run(S.mcp.list_tools())
names = {t.name for t in tools}
ok(names == {"push_training_week", "list_planned_workouts"}, f"exactly two tools, got {names}")
ok(not any("delete" in x or "remove" in x for x in names), "no delete/remove tool is registered")

# ---- bearer auth ----------------------------------------------------------
from starlette.testclient import TestClient
from starlette.applications import Starlette
from starlette.responses import PlainTextResponse
from starlette.routing import Route

inner = Starlette(routes=[Route("/mcp", lambda r: PlainTextResponse("reached inner app"))])
app = S.BearerAuthMiddleware(inner, token="test-token-abc")
c = TestClient(app)

ok(c.get("/mcp").status_code == 401, "no header -> 401")
ok(c.get("/mcp", headers={"Authorization": "Bearer wrong"}).status_code == 401, "wrong token -> 401")
ok(c.get("/mcp", headers={"Authorization": "test-token-abc"}).status_code == 401, "token without Bearer prefix -> 401")
r = c.get("/mcp", headers={"Authorization": "Bearer test-token-abc"})
ok(r.status_code == 200 and "reached inner app" in r.text, "correct token passes through")
ok(c.get("/healthz").status_code == 200, "healthz is open (needed by the host)")

empty = S.BearerAuthMiddleware(inner, token="")
ok(TestClient(empty).get("/mcp", headers={"Authorization": "Bearer "}).status_code == 401,
   "empty configured token never authorises")

# egress restriction
eg = S.BearerAuthMiddleware(inner, token="test-token-abc", enforce_egress=True)
r = TestClient(eg).get("/mcp", headers={"Authorization": "Bearer test-token-abc"})
ok(r.status_code == 403, "non-Anthropic source IP rejected when egress enforcement is on")

# ---- build_app refuses to boot unconfigured -------------------------------
saved = S.BEARER_TOKEN
S.BEARER_TOKEN = ""
try:
    S.build_app(); raise AssertionError("FAILED: build_app booted without a token")
except RuntimeError as exc:
    ok("MCP_BEARER_TOKEN" in str(exc), "refuses to boot without a bearer token")
S.BEARER_TOKEN = saved

print(f"icu-push self-test: {n} checks passed")
